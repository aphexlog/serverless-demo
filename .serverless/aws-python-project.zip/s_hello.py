import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='aphexlog',
    application_name='serverless-demo',
    app_uid='4blxts0r1Rpnqs39zj',
    org_uid='3e87bd8a-41bf-483a-8217-a16bb4b66feb',
    deployment_uid='53e8011a-5af8-4580-8a5c-5a621583f19f',
    service_name='aws-python-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='test',
    plugin_version='7.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-project-test-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
